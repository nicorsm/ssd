// pch.cpp: file di origine corrispondente all'intestazione precompilata, necessario per la riuscita della compilazione

#include "pch.h"

// In generale si può ignorare questo file, ma è necessario mantenerlo se si intende usare intestazioni precompilate.
