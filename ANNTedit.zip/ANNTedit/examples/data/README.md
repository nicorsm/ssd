## Examples' data files

The folder contains some data sets used by example applications. Only trivial data sets are provided, which are small in size. Applications using them will copy required data files during build process to required location, making sure the example may run correctly from the **/build** folder.

Data sets which are required by some application and must be downloaded manually:
*	[MNIST database of handwritten digits](http://yann.lecun.com/exdb/mnist/);
*	[CIFAR-10 data set](https://www.cs.toronto.edu/~kriz/cifar.html).
